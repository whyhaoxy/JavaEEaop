package dev.edu.javaee.spring.aop;

public interface Pointcut {
	//ƥ����
	ClassFilter getClassFilter();
	//ƥ�䷽��
	MethodMatcher getMethodMatcher();
}
