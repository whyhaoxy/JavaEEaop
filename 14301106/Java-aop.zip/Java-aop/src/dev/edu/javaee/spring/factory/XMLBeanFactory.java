package dev.edu.javaee.spring.factory;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import jdk.nashorn.internal.runtime.Property;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import dev.edu.javaee.spring.aop.Advice;
import dev.edu.javaee.spring.bean.BeanDefinition;
import dev.edu.javaee.spring.bean.BeanUtil;
import dev.edu.javaee.spring.bean.PropertyValue;
import dev.edu.javaee.spring.bean.PropertyValues;
import dev.edu.javaee.spring.resource.Resource;

public class XMLBeanFactory extends AbstractBeanFactory {

	private String xmlPath;

	public XMLBeanFactory(Resource resource) {
		try {
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory
					.newInstance();
			DocumentBuilder dbBuilder = dbFactory.newDocumentBuilder();
			Document document = dbBuilder.parse(resource.getInputStream());
			NodeList beanList = document.getElementsByTagName("bean");
			for (int i = 0; i < beanList.getLength(); i++) {
				Node bean = beanList.item(i);
				BeanDefinition beandef = new BeanDefinition();
				String beanClassName = bean.getAttributes()
						.getNamedItem("class").getNodeValue();
				String beanName = bean.getAttributes().getNamedItem("id")
						.getNodeValue();

				beandef.setBeanClassName(beanClassName);

				try {
					Class<?> beanClass = Class.forName(beanClassName);
					beandef.setBeanClass(beanClass);
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				PropertyValues propertyValues = new PropertyValues();

				NodeList propertyList = bean.getChildNodes();
				for (int j = 0; j < propertyList.getLength(); j++) // bean�µ�����property
				{
					Node property = propertyList.item(j);
					if (property instanceof Element) {
						Element ele = (Element) property;

						String name = ele.getAttribute("name");
						Class<?> type;
						try {
							type = beandef.getBeanClass()
									.getDeclaredField(name).getType();
							
							
							//�Բ�ͬ���͵����Խ��н��� �����ӵ�propertyValues��
							if (type == Integer.class) {
								Object value = ele.getAttribute("value");
								value = Integer.parseInt((String) value);
								propertyValues
										.AddPropertyValue(new PropertyValue(
												name, value));
							} else if (type == List.class) {
								List<String> valueList = new ArrayList<String>();
								NodeList thelist = ele
										.getElementsByTagName("list");
								Node list = thelist.item(0);
								NodeList values = ((Element) list)
										.getElementsByTagName("value");
								for (int k = 0; k < values.getLength(); k++) {
									valueList.add(values.item(k)
											.getTextContent()); // ��value�е�ֵ����valueList
								}
								propertyValues
										.AddPropertyValue(new PropertyValue(
												name, valueList));

							} else if (type == Object.class) {
								NodeList theRel = ele
										.getElementsByTagName("ref");
								Node rel = theRel.item(0);
								// NodeList
								// theLocal=((Element)rel).getElementsByTagName("local");
								// //�õ�local
								// �õ�local
								String localName = ((Element) rel)
										.getAttribute("local");

								Object localBean = getBean(localName);
								propertyValues
										.AddPropertyValue(new PropertyValue(
												name, localBean));

							} else if (type == String.class) {
//								NodeList value = ele
//										.getElementsByTagName("value");// �õ�value��Object
//								// Object value = ele.getAttribute("value");
//								// �õ�value��ֵ
//								String valueName = ((Element) value.item(0))
//										.getTextContent();
//								System.out.println(valueName);
								String valueName=ele.getAttribute("value");
								System.out.println(valueName+"\n");
								propertyValues
										.AddPropertyValue(new PropertyValue(
												name, valueName));

							} else if (type == Object[].class) { // ����advisor

								NodeList thelist = ele
										.getElementsByTagName("list");
								Node list = thelist.item(0);
								NodeList values = ((Element) list)
										.getElementsByTagName("value");
								Object[] valueList = new Object[values
										.getLength()];
								for (int k = 0; k < values.getLength(); k++) {
									valueList[k] = this.getBean(values.item(k)
											.getTextContent());
								}
								propertyValues
										.AddPropertyValue(new PropertyValue(
												name, valueList));

							} else if (type == Advice.class) {
								NodeList theRel = ele
										.getElementsByTagName("ref");
								Node rel = theRel.item(0);
								// �õ�local
								String localName = ((Element) rel)
										.getAttribute("local");

								Object localBean = getBean(localName);
								propertyValues
										.AddPropertyValue(new PropertyValue(
												name, localBean));
							}

						} catch (NoSuchFieldException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (SecurityException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					}
				}
				beandef.setPropertyValues(propertyValues);

				this.registerBeanDefinition(beanName, beandef);
			}

		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Override
	protected BeanDefinition GetCreatedBean(BeanDefinition beanDefinition) {

		try {
			// set BeanClass for BeanDefinition

			Class<?> beanClass = beanDefinition.getBeanClass();
			// set Bean Instance for BeanDefinition
			Object bean = beanClass.newInstance();

			List<PropertyValue> fieldDefinitionList = beanDefinition
					.getPropertyValues().GetPropertyValues();
			for (PropertyValue propertyValue : fieldDefinitionList) {
				// ִ��bean�еķ���
				BeanUtil.invokeSetterMethod(bean, propertyValue.getName(),
						propertyValue.getValue());
			}

			beanDefinition.setBean(bean);

			return beanDefinition;

		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
