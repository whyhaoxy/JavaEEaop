package test.edu.javaee.spring.aop;

public interface FooInterface {
	 public void printFoo();
	 public void dummyFoo();
}
