package test.edu.javaee.spring.ioc;

import dev.edu.javaee.spring.aop.Advisor;
import dev.edu.javaee.spring.aop.framework.AdvisedSupport;
import dev.edu.javaee.spring.aop.framework.JdkDynamicAopProxy;
import dev.edu.javaee.spring.aop.framework.ProxyFactory;

public class ProxyFactoryBean {
	private String proxyInterfaces;	//�ӿ�
	private Object target;			//Ŀ��
	private Object[] interceptorNames;	//����
	
	AdvisedSupport advisedSupport=new AdvisedSupport();
	public void setProxyInterfaces(String proxyInterfaces) throws ClassNotFoundException{
		this.proxyInterfaces=proxyInterfaces;
		this.advisedSupport.setInterfaces(Class.forName(proxyInterfaces));
		
	}
	public void setTarget(Object target){
		this.target=target;
		this.advisedSupport.setTarget(target);
	}
	public  void setInterceptorNames(Object[] interceptorNames){
		this.interceptorNames=interceptorNames;
		for(int i=0;i<interceptorNames.length;i++){
			this.advisedSupport.addAdvisor((Advisor)interceptorNames[i]);
		}
	}
	public Object getProxy(){
		
		return new JdkDynamicAopProxy(advisedSupport).getProxy();	
	}
}
